#!/usr/bin/env python3
"""Phase 74 証跡アーカイブの検証。使い方: python3 verify.py [--repo <auto_developer の clone>]"""
import hashlib, json, pathlib, subprocess, sys, collections
ROOT = pathlib.Path(__file__).resolve().parent
ok = True
def check(cond, msg):
    global ok
    print(('OK   ' if cond else 'FAIL ') + msg); ok &= bool(cond)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

# 1. 収録ファイルのハッシュ
sums = [l.split('  ', 1) for l in (ROOT/'SHA256SUMS').read_text().splitlines() if l]
bad = [f for h, f in sums if sha(ROOT/f) != h]
check(not bad, f'SHA256SUMS: {len(sums)} files' + (f' mismatched={bad}' if bad else ''))

# 2. イベント記録の集計
ev = [json.loads(l) for l in (ROOT/'events_phase74.jsonl').read_text().splitlines() if l]
k = collections.Counter(e['event'] for e in ev)
dec = collections.Counter(e.get('decision') for e in ev if e['event'] == 'checker_review')
ver = collections.Counter(e.get('result') for e in ev if e['event'] == 'verify_step')
print('     events', dict(k)); print('     verify', dict(ver)); print('     review', dict(dec))
check(k['commit_step'] == 8 and k['rollback_step'] == 3 and k['checker_review'] == 15, 'events: commit 8 / rollback 3 / review 15')

# 3. 査読履歴: 記録されたハッシュと、写しの中身が一致するか
rev = ROOT/'evidence'/'reviews'; hist_dec = collections.Counter(); n = 0
for rj in sorted(rev.glob('task_*/history/*/review.json')):
    r = json.loads(rj.read_text()); d = rj.parent; n += 1
    hist_dec[r.get('decision') or 'UNDECIDED'] += 1
    for key, fn in (('checker_output_sha256', 'checker_output.txt'), ('diff_sha256', 'diff.patch'), ('spec_sha256', 'spec_excerpt.md')):
        check(sha(d/fn) == r[key], f'{d.relative_to(ROOT)}/{fn} == {key}')
check(n == 15 and hist_dec == dec, f'review history: {n} entries, decisions {dict(hist_dec)} match events')

# 4. Evidence: 確定に使われた査読の写しとコミット
heads = [l for l in (ROOT/'git'/'commits.txt').read_text().splitlines() if len(l.split()) > 1 and len(l.split()[0]) == 40]
commits = [l.split()[0] for l in heads if '[refs:' in l]          # パイプラインによる確定
others = [l.split()[0][:7] + ' ' + l.split(' ', 2)[2] for l in heads if '[refs:' not in l]
print('     non-pipeline commits in range:', others or 'none')
ev_commits = []
for t in range(1, 9):
    e = json.loads((ROOT/'evidence'/f'task_{t}.json').read_text()); rv = e['checker']['review']; d = rev/f'task_{t}'
    check(e['checker']['decision'] == 'APPROVE' and e['status'] == 'COMPLETED', f'task {t}: evidence consumed with APPROVE')
    check(sha(d/'checker_output.txt') == rv['output_sha256'] and sha(d/'diff.patch') == rv['diff_sha256'] and sha(d/'spec_excerpt.md') == rv['spec_sha256'], f'task {t}: final review copies match evidence')
    check(e['commit']['tree_sha'] == e['tree_sha'], f'task {t}: commit tree == verified tree')
    ev_commits.append(e['commit']['commit_sha'])
check(ev_commits == commits, 'evidence commits == pipeline commits in git/commits.txt (in order)')

# 5. 任意: リポジトリの clone と照合
if '--repo' in sys.argv:
    repo = sys.argv[sys.argv.index('--repo') + 1]
    g = lambda *a: subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True)
    for t, c in enumerate(ev_commits, 1):
        tree = g('rev-parse', c + '^{tree}').stdout.strip()
        exp = json.loads((ROOT/'evidence'/f'task_{t}.json').read_text())['tree_sha']
        check(tree == exp, f'repo: {c[:7]} tree == evidence tree_sha')
    check(g('bundle', 'verify', str(ROOT/'git'/'quarantine_phase74.bundle')).returncode == 0, 'repo: quarantine bundle verifies against clone')

print('\nRESULT:', 'ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED'); sys.exit(0 if ok else 1)
