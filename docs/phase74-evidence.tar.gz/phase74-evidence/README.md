# Auto Developer Phase 74 証跡アーカイブ

論文「自律型AIエージェント時代におけるソフトウェア工学の再定義」v2.0 の 8.1 節が根拠とする、Phase 74（v0.10.0 の手直し、8タスク）の実行記録です。対象の期間は 2026-11-25 00:25〜11:07（JST）です。

- リポジトリ: https://github.com/hamatz/auto_developer
- 範囲: `9eb4589`（Phase 74 の準備）..`228ea07`（タスク 8 の確定）
- 作成日: 2026-11-27。作成元は筆者の手元のリポジトリです（`.git/nightly_evidence/`、Git の履歴、隔離ブランチ）。

## 収録物

| パス | 内容 | 元の場所 |
|---|---|---|
| `events_phase74.jsonl` | Auto Developer が書いたイベント記録のうち Phase 74 の 62 件 | `.git/nightly_evidence/events.jsonl` |
| `evidence/task_<n>.json` | 各タスクの Evidence（検証の記録と、確定に使った査読・コミット） | `.git/nightly_evidence/archive/phase74/` |
| `evidence/reviews/task_<n>/history/<k>/` | 査読の全履歴 15 件（REJECT を含む）。Checker への入力（差分・仕様の抜粋）と Checker の出力の写し、記録 `review.json` | 同上 |
| `evidence/reviews/task_<n>/` 直下 | 確定に使われた最新の査読の写し | 同上 |
| `git/commits.txt`、`git/range_shortstat.txt` | 範囲内のコミットと差分の大きさ | Git |
| `git/quarantine_phase74.bundle`、`git/quarantine_refs.txt` | 隔離ブランチ 3 本（タスク 5・7・8） | `quarantine/*` |
| `dashboard_phase74.html` | `auto-dev` のダッシュボードの再生（記録から生成した表示） | `.dev/review74/repo.html` |
| `verify.py`、`SHA256SUMS` | 検証スクリプトと、収録ファイルのハッシュ | — |

## 加工した点

- **JSON の中の絶対パス**: 手元のリポジトリのパスを `<REPO>` に置き換えました。
- **Evidence のトークン**（`token`、`evidence_token`）: 値を `sha256:<トークンの SHA-256>` に置き換えました。どれも消費済みの一回限りの値です。同じトークンは同じ値になるので、査読と Evidence の対応は追えます。
- **査読の入出力**（`checker_output.txt`、`diff.patch`、`spec_excerpt.md`）は変更していません。`review.json` と Evidence に記録された SHA-256 と、そのまま照合できます。
- **含めていないもの**: 隔離時の作業ツリーのスナップショットとそのファイル一覧（キャッシュなど作業環境のファイルを含むため）、Phase 74 以外の記録。

## 人間の介入（4 回）

この実行は無人では完結していません。

1. **タスク 4（03:17〜06:41）**: 保護された免疫テスト `tests/immunity/test_immunity_checker_policy.py` が、GATE-13 が塞ぐ「REJECT の後に同じ検証へ APPROVE を記録し直す」動作を前提にしていたため、検証が失敗して停止しました。免疫テストは人間だけが変更できます。筆者がテストを直し（`8a99ca2`「免疫テストの修正」。範囲内で唯一の、パイプライン外のコミット）、新しい HEAD をチェックポイントにして検証からやり直しました。経緯は同コミットの `PLAN.md` の記録にあります。
2. **タスク 5・7・8**: 同じタスクで REJECT が 2 回続いたため隔離され（INV-4）、オーケストレーター（Antigravity）が停止しました。筆者が Claude Code で停止時の相談文を確認して必要な修正を加え、Antigravity に再開を指示しました。この再開の判断と修正の内容は、イベント記録には残っていません（筆者の証言による）。

## 検証のしかた

```sh
python3 verify.py                        # アーカイブの中だけで照合する
python3 verify.py --repo path/to/auto_developer   # clone のコミット・ツリーとも照合する
```

`verify.py` は次を確かめます。

- 収録ファイルのハッシュ
- イベントの件数
- 15 件の査読履歴のハッシュと、その判定がイベント記録と一致すること
- 8 件の Evidence が APPROVE で消費され、そのツリーとコミットが一致すること

`--repo` を付けると、コミットのツリーと隔離ブランチの bundle も照合します。bundle の照合には、`9eb4589` を含む clone が必要です。

## 限界

- イベント記録と Evidence は Auto Developer 自身が書いたものです。署名や外部の追記型記録による信頼基点はありません。このアーカイブが示すのは記録どうしの整合性であり、記録が改ざんされていないことの証明ではありません。
- モデルの系統（`*_family`）は、モデル名から推定した値です（`family_source: inferred`）。
- `dashboard_phase74.html` の上部の注意表示（隔離ブランチ、AUDIT_OUTDATED）は、実行時ではなく HTML を生成した時点の状態です。
